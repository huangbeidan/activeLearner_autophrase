0.# activeLearner_autophrase

## Running Steps
First, run lsh_qutophrase.py to get lsh similarity groups

Next, run lsh_analyzer.py to start the active learning process
